package nr.astral;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;

/** Same shared-key gate as the root build: one key for everyone, local hash compare, no network. */
final class KeyGate {
    private static final String PREFS = "astral_lic";

    // sha256("ASTRAL-NEBULA-9X7Q") -- the key posted at https://t.me/AstralEXEmobile
    private static final String KEY_SHA256 = "9ffcb1632924b1270db6e39f82a81a0d79b441b47ed2d6955bcb1c77786f5a7c";

    static final class Result {
        final boolean ok; final String reason;
        Result(boolean ok, String reason) { this.ok = ok; this.reason = reason; }
    }

    private static SharedPreferences sp(Context ctx) { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    static boolean quickCheck(Context ctx) { return sp(ctx).getBoolean("unlocked", false); }

    static Result check(Context ctx, String rawKey) {
        if (rawKey == null || rawKey.trim().isEmpty()) return new Result(false, "format");
        String key = rawKey.trim().toUpperCase(java.util.Locale.US);
        boolean ok = sha256Hex(key).equals(KEY_SHA256);
        if (ok) sp(ctx).edit().putBoolean("unlocked", true).apply();
        return new Result(ok, ok ? "ok" : "bad_key");
    }
}
