package nr.astral;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Does nothing but exist and hold a TouchInjector -- "Enable accessibility" in settings is the
 *  no-root stand-in for su. No window content is read (canRetrieveWindowContent=false in the
 *  config), this service only ever dispatches gestures. */
public class ClumsyAccessibilityService extends AccessibilityService {
    private static volatile ClumsyAccessibilityService instance;
    private TouchInjector injector;

    static ClumsyAccessibilityService get() { return instance; }
    TouchInjector injector() { return injector; }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        injector = new TouchInjector(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* unused */ }
    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (injector != null) injector.lift();
        instance = null;
        return super.onUnbind(intent);
    }

    static boolean isOn() { return instance != null; }
}
