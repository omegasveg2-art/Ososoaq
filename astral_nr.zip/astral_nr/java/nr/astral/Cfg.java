package nr.astral;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

final class Cfg {
    static final HashMap<String, Float> DEF = new HashMap<>();
    static final HashMap<String, Float> V = new HashMap<>();

    private static void d(String k, float v) { DEF.put(k, v); }

    static {
        d("fov", 160);          // detect radius around screen center, px
        d("seconds", 1.2f);     // how long "Clumsy" holds the freeze+fire
        d("smooth", 0.35f);     // 0..1, finger lerp toward target each tick (1 = snap)
        d("tickMs", 16);        // touch update interval while armed
        d("fireMs", 60);        // tap-and-release cadence for auto-fire during the hold
        d("minBlob", 30);       // minimum matching pixels to accept a detection
        d("tolH", 14);          // hue tolerance, degrees (0-180 opencv-style not used here, 0-360)
        d("tolS", 60);          // saturation tolerance, 0-255 scale
        d("tolV", 60);          // value tolerance, 0-255 scale
        d("targetHue", -1);     // -1 = not calibrated yet
        d("targetSat", 0);
        d("targetVal", 0);
        d("fireX", 0.92f);      // fire button position, fraction of screen W
        d("fireY", 0.65f);      // fraction of screen H
        d("btnSize", 46);       // Clumsy floating button size, dp
        d("scanStep", 4);       // sample every Nth pixel when scanning a frame (perf knob)
        V.putAll(DEF);
    }

    static float f(String k) { Float v = V.get(k); return v == null ? 0f : v; }
    static int i(String k) { return Math.round(f(k)); }
    static boolean calibrated() { return f("targetHue") >= 0; }
    static void set(String k, float v) { V.put(k, v); }
    static void reset() { V.clear(); V.putAll(DEF); }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("astral_nr_cfg", Context.MODE_PRIVATE); }

    static void load(Context c) {
        SharedPreferences p = sp(c);
        for (Map.Entry<String, Float> e : DEF.entrySet()) V.put(e.getKey(), p.getFloat(e.getKey(), e.getValue()));
    }

    static void save(Context c) {
        SharedPreferences.Editor ed = sp(c).edit();
        for (Map.Entry<String, Float> e : V.entrySet()) ed.putFloat(e.getKey(), e.getValue());
        ed.apply();
    }
}
