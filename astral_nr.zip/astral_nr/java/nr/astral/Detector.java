package nr.astral;

import android.graphics.Bitmap;
import android.graphics.Color;

/**
 * Nearest-blob-to-center color detector. Deliberately dumb: scans a square window around the
 * crosshair (not the whole frame -- that's both faster and naturally picks "whatever's closest
 * to where you're already aiming" instead of needing real blob segmentation). Hue/sat/val are on
 * a 0-360 / 0-100 / 0-100 scale to match what you'd read off a color picker.
 */
final class Detector {

    static final class Hit { float x, y; int count; }

    /** bmp is the captured frame, already the same pixel size as the screen (VirtualDisplay is set up 1:1).
     *  cx,cy,fov are in bitmap pixel space. Returns null if nothing matched enough pixels. */
    static Hit findTarget(Bitmap bmp, int cx, int cy, int fov, float targetHue, float targetSat, float targetVal,
                            float tolH, float tolS, float tolV, int step, int minBlob) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int left = Math.max(0, cx - fov), right = Math.min(w - 1, cx + fov);
        int top = Math.max(0, cy - fov), bottom = Math.min(h - 1, cy + fov);
        if (left >= right || top >= bottom) return null;

        long sumX = 0, sumY = 0; int n = 0;
        float[] hsv = new float[3];
        int fov2 = fov * fov;

        for (int y = top; y <= bottom; y += step) {
            int dy = y - cy;
            for (int x = left; x <= right; x += step) {
                int dx = x - cx;
                if (dx * dx + dy * dy > fov2) continue;
                int p = bmp.getPixel(x, y);
                Color.RGBToHSV(Color.red(p), Color.green(p), Color.blue(p), hsv);
                float hue = hsv[0], sat = hsv[1] * 100f, val = hsv[2] * 100f;
                float dh = Math.abs(hue - targetHue);
                if (dh > 180) dh = 360 - dh;
                if (dh > tolH || Math.abs(sat - targetSat) > tolS || Math.abs(val - targetVal) > tolV) continue;
                sumX += x; sumY += y; n++;
            }
        }
        if (n < minBlob) return null;
        Hit hit = new Hit();
        hit.x = sumX / (float) n;
        hit.y = sumY / (float) n;
        hit.count = n;
        return hit;
    }

    /** samples one pixel's HSV, for the "pick enemy color" calibration tap. */
    static float[] sampleHsv(Bitmap bmp, int x, int y) {
        x = Math.max(0, Math.min(bmp.getWidth() - 1, x));
        y = Math.max(0, Math.min(bmp.getHeight() - 1, y));
        int p = bmp.getPixel(x, y);
        float[] hsv = new float[3];
        Color.RGBToHSV(Color.red(p), Color.green(p), Color.blue(p), hsv);
        return new float[]{hsv[0], hsv[1] * 100f, hsv[2] * 100f};
    }
}
