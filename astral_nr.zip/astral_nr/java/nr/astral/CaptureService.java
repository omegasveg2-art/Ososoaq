package nr.astral;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;

/**
 * Foreground service holding the MediaProjection screen capture and the "Clumsy" one-shot
 * aim+fire routine. Capture runs continuously at the display's own frame rate (ImageReader
 * listener, not polling) so there's always a recent frame ready; the Clumsy loop only runs for
 * Cfg "seconds" after the floating button is pressed.
 */
public class CaptureService extends Service {
    private static volatile CaptureService instance;
    static CaptureService get() { return instance; }

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;
    private HandlerThread capThread;
    private Handler capHandler;
    private volatile Bitmap latest;
    private int screenW, screenH;

    private final Handler ui = new Handler(android.os.Looper.getMainLooper());
    private volatile boolean armed = false;
    private volatile boolean running = true;
    private long nextFire = 0;

    private WindowManager wm;
    private TextView fab;
    private LinearLayout panel;
    private WindowManager.LayoutParams fabLp, panelLp;
    private View pickCatcher; // full-screen transparent view, active only during color/fire-point pick

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent in, int flags, int id) {
        instance = this;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("cap", "Astral.exe", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "cap").setContentTitle("Astral.exe is running").setSmallIcon(android.R.drawable.ic_menu_view).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(2, n);

        Cfg.load(this);
        if (vdisplay == null && in != null) {
            int resultCode = in.getIntExtra("resultCode", 0);
            Intent data = in.getParcelableExtra("data");
            if (data != null) { startCapture(resultCode, data); ui.post(this::addFab); }
        }
        return START_STICKY;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private WindowManager.LayoutParams params(int w, int h, int extraFlags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                extraFlags | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return lp;
    }

    private android.graphics.drawable.GradientDrawable rounded(int fill, int stroke, float r) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    /** draggable round "Clumsy" button: tap = fire the lock+rage routine, long-press = settings panel. */
    private void addFab() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        fab = new TextView(this);
        fab.setText("C");
        fab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        fab.setTextColor(0xFF5AB0FF);
        fab.setGravity(Gravity.CENTER);
        fab.setBackground(rounded(0xCC101215, 0xFF5AB0FF, 99));
        int sz = dp(Cfg.f("btnSize"));
        fabLp = params(sz, sz, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        fabLp.x = dp(6); fabLp.y = dp(200);
        fab.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved; long downAt;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); sx = fabLp.x; sy = fabLp.y; moved = false; downAt = System.currentTimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > dp(6) || Math.abs(e.getRawY() - dy) > dp(6)) moved = true;
                        if (moved) { fabLp.x = sx + (int) (e.getRawX() - dx); fabLp.y = sy + (int) (e.getRawY() - dy); wm.updateViewLayout(fab, fabLp); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            if (System.currentTimeMillis() - downAt > 450) toggleSettings();
                            else triggerClumsy();
                        }
                        return true;
                    default: return false;
                }
            }
        });
        wm.addView(fab, fabLp);
    }

    private TextView rowLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(12); v.setTextColor(0xFFE8EAED);
        return v;
    }

    private TextView stepBtn(String t, Runnable onClick) {
        TextView b = new TextView(this);
        b.setText(t); b.setTextSize(16); b.setTextColor(0xFF5AB0FF); b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(0xFF171A1F, 0xFF262B32, 6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(30));
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    /** one settings row: label, -, current value, +. step is applied to Cfg[key]. */
    private LinearLayout sliderRow(String label, String key, float step, float min, float max) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView lab = rowLabel(label);
        lab.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(lab);
        TextView val = rowLabel(fmt(Cfg.f(key)));
        val.setTextColor(0xFF8B929B);
        val.setLayoutParams(new LinearLayout.LayoutParams(dp(50), -2));
        row.addView(stepBtn("-", () -> { Cfg.set(key, clamp(Cfg.f(key) - step, min, max)); val.setText(fmt(Cfg.f(key))); Cfg.save(this); }));
        row.addView(val);
        row.addView(stepBtn("+", () -> { Cfg.set(key, clamp(Cfg.f(key) + step, min, max)); val.setText(fmt(Cfg.f(key))); Cfg.save(this); }));
        return row;
    }

    private static String fmt(float v) { return Math.abs(v - Math.round(v)) < 0.01f ? String.valueOf(Math.round(v)) : String.format(java.util.Locale.US, "%.2f", v); }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void toggleSettings() {
        if (panel != null) { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; return; }

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(0xF0171A1F, 0xFF262B32, 14));
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView title = rowLabel("Astral.exe — Clumsy");
        title.setTextSize(15); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        panel.addView(title);

        TextView swatch = rowLabel(Cfg.calibrated() ? "color set" : "not calibrated — tap Pick color");
        swatch.setTextColor(Cfg.calibrated() ? 0xFF4ADE80 : 0xFFFF9F1A);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(6);
        panel.addView(swatch, sp);

        panel.addView(sliderRow("FOV (px)", "fov", 10, 20, 400));
        panel.addView(sliderRow("Seconds", "seconds", 0.1f, 0.2f, 5f));
        panel.addView(sliderRow("Smooth", "smooth", 0.05f, 0.05f, 1f));
        panel.addView(sliderRow("Fire ms", "fireMs", 10, 20, 300));
        panel.addView(sliderRow("Tol H", "tolH", 2, 2, 60));
        panel.addView(sliderRow("Tol S", "tolS", 5, 5, 100));
        panel.addView(sliderRow("Tol V", "tolV", 5, 5, 100));

        TextView pick = rowLabel("Pick color (tap enemy)");
        pick.setTextColor(0xFF5AB0FF);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.topMargin = dp(10);
        pick.setLayoutParams(pp);
        pick.setOnClickListener(v -> startPick(true, swatch));
        panel.addView(pick);

        TextView firePt = rowLabel("Set fire button position (tap)");
        firePt.setTextColor(0xFF5AB0FF);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(8);
        firePt.setLayoutParams(fp);
        firePt.setOnClickListener(v -> startPick(false, swatch));
        panel.addView(firePt);

        panelLp = params(dp(240), -2, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        panelLp.x = fabLp.x + dp(50); panelLp.y = fabLp.y;
        wm.addView(panel, panelLp);
    }

    /** one-tap full-screen catcher: next tap either samples the color under it (calibration) or
     *  stores its position as the fire-button point, depending on `forColor`. */
    private void startPick(boolean forColor, TextView swatch) {
        if (pickCatcher != null) return;
        pickCatcher = new View(this);
        pickCatcher.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN) return true;
            int x = (int) e.getRawX(), y = (int) e.getRawY();
            if (forColor) {
                float[] hsv = sampleAt(x, y);
                if (hsv != null) {
                    Cfg.set("targetHue", hsv[0]); Cfg.set("targetSat", hsv[1]); Cfg.set("targetVal", hsv[2]);
                    Cfg.save(this);
                    swatch.setText("color set"); swatch.setTextColor(0xFF4ADE80);
                }
            } else {
                Cfg.set("fireX", x / (float) screenW); Cfg.set("fireY", y / (float) screenH);
                Cfg.save(this);
            }
            try { wm.removeView(pickCatcher); } catch (Exception ignored) {}
            pickCatcher = null;
            return true;
        });
        WindowManager.LayoutParams lp = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0);
        wm.addView(pickCatcher, lp);
    }

    private void startCapture(int resultCode, Intent data) {
        MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(resultCode, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopSelf(); }
        }, ui);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels; screenH = dm.heightPixels;
        int density = dm.densityDpi;

        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
        capThread = new HandlerThread("astral-capture");
        capThread.start();
        capHandler = new Handler(capThread.getLooper());
        reader.setOnImageAvailableListener(r -> {
            try (Image image = r.acquireLatestImage()) {
                if (image == null) return;
                latest = toBitmap(image);
            } catch (Exception ignored) {}
        }, capHandler);

        vdisplay = projection.createVirtualDisplay("astral-cap", screenW, screenH, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, capHandler);
    }

    private Bitmap toBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * screenW;
        Bitmap full = Bitmap.createBitmap(screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888);
        full.copyPixelsFromBuffer(buf);
        if (rowPadding == 0) return full;
        Bitmap cropped = Bitmap.createBitmap(full, 0, 0, screenW, screenH);
        full.recycle();
        return cropped;
    }

    // ---- calibration: sample the color under a tap, in screen pixel coords ----
    float[] sampleAt(int x, int y) {
        Bitmap b = latest;
        if (b == null) return null;
        return Detector.sampleHsv(b, x, y);
    }

    // ---- Clumsy: press -> lock aim onto nearest matching blob near center, auto-fire, for Cfg.seconds ----
    void triggerClumsy() {
        if (armed) return;
        ClumsyAccessibilityService svc = ClumsyAccessibilityService.get();
        if (svc == null || svc.injector() == null) return; // accessibility not enabled
        if (!Cfg.calibrated()) return; // nothing to aim at
        armed = true;
        long durMs = (long) (Cfg.f("seconds") * 1000);
        long tickMs = Math.max(8, Cfg.i("tickMs"));
        long start = System.currentTimeMillis();
        nextFire = 0;
        capHandler.post(new Runnable() {
            @Override public void run() {
                if (!running || !armed) return;
                long now = System.currentTimeMillis();
                if (now - start >= durMs) { endClumsy(svc); return; }
                stepClumsy(svc, now);
                capHandler.postDelayed(this, tickMs);
            }
        });
    }

    private void stepClumsy(ClumsyAccessibilityService svc, long now) {
        Bitmap b = latest;
        if (b == null) return;
        int cx = screenW / 2, cy = screenH / 2;
        Detector.Hit hit = Detector.findTarget(b, cx, cy, Cfg.i("fov"),
                Cfg.f("targetHue"), Cfg.f("targetSat"), Cfg.f("targetVal"),
                Cfg.f("tolH"), Cfg.f("tolS"), Cfg.f("tolV"), Math.max(1, Cfg.i("scanStep")), Cfg.i("minBlob"));
        TouchInjector inj = svc.injector();
        if (hit != null) {
            float smooth = Cfg.f("smooth");
            float tx, ty;
            if (!inj.active()) { tx = hit.x; ty = hit.y; } // snap on first lock
            else { tx = inj.lastX() + (hit.x - inj.lastX()) * smooth; ty = inj.lastY() + (hit.y - inj.lastY()) * smooth; }
            inj.move(tx, ty);

            if (now >= nextFire) {
                nextFire = now + Math.max(16, Cfg.i("fireMs"));
                inj.tap(Cfg.f("fireX") * screenW, Cfg.f("fireY") * screenH, 20);
            }
        }
        // no hit this tick: keep the finger where it last was (holds the lock through a brief occlusion/flicker)
    }

    private void endClumsy(ClumsyAccessibilityService svc) {
        armed = false;
        if (svc != null && svc.injector() != null) svc.injector().lift();
    }

    @Override
    public void onDestroy() {
        running = false;
        armed = false;
        try { if (vdisplay != null) vdisplay.release(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        if (capThread != null) capThread.quitSafely();
        try { if (fab != null) wm.removeView(fab); } catch (Exception ignored) {}
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        try { if (pickCatcher != null) wm.removeView(pickCatcher); } catch (Exception ignored) {}
        instance = null;
        super.onDestroy();
    }
}
