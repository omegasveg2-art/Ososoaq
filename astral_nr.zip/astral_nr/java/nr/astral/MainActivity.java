package nr.astral;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** No-root launcher: three permissions, then Clumsy's floating button does the rest. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0E1013, CARD = 0xFF171A1F, EDGE = 0xFF262B32, ACCENT = 0xFF5AB0FF, TEXT = 0xFFE8EAED, DIM = 0xFF8B929B;
    private static final int REQ_CAPTURE = 42;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, int col, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(col);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private TextView button(String t, int fill, int textCol, View.OnClickListener l) {
        TextView b = label(t, 15, textCol, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(fill, fill == CARD ? EDGE : 0, 12));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        if (Anti.looksTampered(this)) { finish(); return; }
        if (!KeyGate.quickCheck(this)) { showKeyDialog(); return; }
        buildUi();
    }

    private void showKeyDialog() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(24), dp(20), dp(24), dp(4));

        wrap.addView(label("Astral.exe", 24, TEXT, true));
        final TextView status = label("Enter your license key to continue.", 13, DIM, false);
        wrap.addView(status);

        final EditText input = new EditText(this);
        input.setHint("ASTRAL-XXXX-XXXX-XXXX");
        input.setHintTextColor(DIM);
        input.setTextColor(TEXT);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setBackground(rounded(CARD, EDGE, 10));
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(16);
        wrap.addView(input, ip);

        TextView buy = label("No key? Buy one: t.me/AstralEXEmobile", 12, ACCENT, false);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(10);
        buy.setLayoutParams(bp);
        buy.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/AstralEXEmobile"))); } catch (Exception ignored) {} });
        wrap.addView(buy);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setView(wrap).setCancelable(false)
                .setPositiveButton("Activate", null)
                .setNegativeButton("Exit", (d, w) -> finish())
                .create();
        dlg.getWindow().getAttributes().dimAmount = 0.85f;
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            KeyGate.Result r = KeyGate.check(this, input.getText().toString());
            if (r.ok) { dlg.dismiss(); buildUi(); return; }
            status.setText(r.reason.equals("format") ? "Enter a key first." : "Invalid key.");
        });
    }

    private void buildUi() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(BG);
        l.setPadding(dp(20), dp(44), dp(20), dp(20));

        TextView title = label("Astral.exe", 34, TEXT, true);
        title.setLetterSpacing(0.04f);
        l.addView(title);
        l.addView(label("Screen-capture Clumsy assist · no root needed", 13, DIM, false));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(CARD, EDGE, 14));
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(22);
        card.addView(label("How it works", 12, DIM, true));
        card.addView(label("1  Allow the overlay\n2  Turn on Accessibility for Astral.exe\n3  Start — allow screen capture when asked\n4  Long-press the floating C button to pick the enemy color and settings\n5  Tap C to lock + fire for a moment", 14, TEXT, false));
        l.addView(card, cp);

        l.addView(button("1   Allow overlay", CARD, TEXT, v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        l.addView(button("2   Enable accessibility", CARD, TEXT, v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(button("3   Start", ACCENT, 0xFF0B0D10, v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Allow the overlay first (step 1)", Toast.LENGTH_LONG).show(); return; }
            if (!ClumsyAccessibilityService.isOn()) { Toast.makeText(this, "Turn on Accessibility for Astral.exe first (step 2)", Toast.LENGTH_LONG).show(); return; }
            MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE);
        }));
        l.addView(button("Stop", CARD, 0xFFFF6B5E, v -> stopService(new Intent(this, CaptureService.class))));

        TextView foot = label("Nothing is injected into the game — this just watches the screen and taps for you.", 12, DIM, false);
        foot.setPadding(0, dp(18), 0, 0);
        l.addView(foot);
        setContentView(l);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("resultCode", res);
            i.putExtra("data", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Running. Long-press the C button to pick the enemy color first.", Toast.LENGTH_LONG).show();
        } else if (req == REQ_CAPTURE) {
            Toast.makeText(this, "Screen capture was declined.", Toast.LENGTH_SHORT).show();
        }
    }
}
