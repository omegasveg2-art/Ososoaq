package nr.astral;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;

/**
 * Synthetic touch via AccessibilityService.dispatchGesture -- the no-root equivalent of writing
 * to /dev/uinput. One continuous finger is kept down with StrokeDescription.continueStroke() so
 * "move" reads as a drag, not a new tap every frame; a second, independent single-tap stroke is
 * used for the fire button so it doesn't fight the aim finger. Needs API 26+ (continueStroke).
 */
final class TouchInjector {
    private final AccessibilityService svc;
    private GestureDescription.StrokeDescription aimStroke; // null when finger is up
    private float lastX, lastY;

    TouchInjector(AccessibilityService svc) { this.svc = svc; }

    boolean active() { return aimStroke != null; }
    float lastX() { return lastX; }
    float lastY() { return lastY; }

    /** puts the aim finger down at (x,y). Call once before the first move(). */
    void start(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        aimStroke = new GestureDescription.StrokeDescription(p, 0, 16, true);
        dispatch(aimStroke);
        lastX = x; lastY = y;
    }

    /** continues the held-down finger to a new point. */
    void move(float x, float y) {
        if (aimStroke == null) { start(x, y); return; }
        Path p = new Path();
        p.moveTo(lastX, lastY);
        p.lineTo(x, y);
        GestureDescription.StrokeDescription next = aimStroke.continueStroke(p, 0, 16, true);
        if (dispatch(next)) aimStroke = next;
        lastX = x; lastY = y;
    }

    /** lifts the aim finger. */
    void lift() {
        if (aimStroke == null) return;
        Path p = new Path();
        p.moveTo(lastX, lastY);
        GestureDescription.StrokeDescription end = aimStroke.continueStroke(p, 0, 1, false);
        dispatch(end);
        aimStroke = null;
    }

    /** one quick independent tap (fire button), doesn't touch the aim finger's stroke chain. */
    void tap(float x, float y, long durMs) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(p, 0, Math.max(1, durMs), false);
        dispatch(s);
    }

    private boolean dispatch(GestureDescription.StrokeDescription s) {
        if (Build.VERSION.SDK_INT < 26) return false;
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(s);
        return svc.dispatchGesture(b.build(), null, null);
    }
}
